# Instagram Integration - Senior Engineer Review Document

**Date:** 2026-01-15
**Purpose:** Compilation of all Instagram-related service/repository files, SQL edge functions, and identified issues for senior software engineer review.

---

## Executive Summary

The Instagram DM integration is a comprehensive system with **9 edge functions**, **18 database migrations**, **6 repository files**, **2 hook files**, and **20+ UI components**. Two issues have been identified:

1. **Conversation sync failures** - Conversations periodically fail to load/sync after initial load
2. **Missing IG username field** - No field to store Instagram username when creating a lead from a conversation

---

## PART 1: Complete File Inventory

### 1.1 Core Service Layer

| File | Lines | Purpose |
|------|-------|---------|
| `src/services/instagram/instagramService.ts` | 629 | Facade composing all repositories |
| `src/services/instagram/index.ts` | - | Service exports |

### 1.2 Repository Layer (Data Access)

| File | Lines | Purpose |
|------|-------|---------|
| `src/services/instagram/repositories/InstagramIntegrationRepository.ts` | 92 | OAuth integrations management |
| `src/services/instagram/repositories/InstagramConversationRepository.ts` | 223 | Conversations, priority, contact info, lead creation |
| `src/services/instagram/repositories/InstagramMessageRepository.ts` | 66 | Message storage (insert-only) |
| `src/services/instagram/repositories/InstagramScheduledMessageRepository.ts` | 189 | Scheduled/delayed messages |
| `src/services/instagram/repositories/InstagramTemplateRepository.ts` | 130 | Message templates |
| `src/services/instagram/repositories/InstagramTemplateCategoryRepository.ts` | 87 | Custom template categories |

**Total Repository Code: ~787 lines**

### 1.3 React Hooks (TanStack Query)

| File | Lines | Purpose |
|------|-------|---------|
| `src/hooks/instagram/useInstagramIntegration.ts` | 897 | All TanStack Query hooks for Instagram operations |
| `src/hooks/instagram/useInstagramRealtime.ts` | 211 | Realtime Supabase subscriptions |
| `src/hooks/instagram/index.ts` | 46 | Hook exports |

**Total Hook Code: ~1,154 lines**

### 1.4 Utility Functions

| File | Lines | Purpose |
|------|-------|---------|
| `src/lib/instagram/selectors.ts` | 142 | UI computation functions (window status, formatting) |
| `src/lib/nameParser.ts` | - | Parse IG display name to first/last |

---

## PART 2: Supabase Edge Functions (9 Functions)

### 2.1 OAuth Functions

| Function | Path | Purpose |
|----------|------|---------|
| `instagram-oauth-init` | `supabase/functions/instagram-oauth-init/index.ts` | Generate Meta OAuth URL |
| `instagram-oauth-callback` | `supabase/functions/instagram-oauth-callback/index.ts` | Handle OAuth callback, store encrypted tokens |

### 2.2 Data Sync Functions

| Function | Path | Purpose |
|----------|------|---------|
| `instagram-get-conversations` | `supabase/functions/instagram-get-conversations/index.ts` | Fetch conversations from Instagram API |
| `instagram-get-messages` | `supabase/functions/instagram-get-messages/index.ts` | Fetch messages for a conversation |
| `instagram-send-message` | `supabase/functions/instagram-send-message/index.ts` | Send DM via Instagram API |

### 2.3 Background/CRON Functions

| Function | Path | Schedule | Purpose |
|----------|------|----------|---------|
| `instagram-webhook` | `supabase/functions/instagram-webhook/index.ts` | On webhook | Handle Meta webhooks for real-time messages |
| `instagram-process-scheduled` | `supabase/functions/instagram-process-scheduled/index.ts` | Every 5 min | Process scheduled messages, expire windows |
| `instagram-process-jobs` | `supabase/functions/instagram-process-jobs/index.ts` | Every 1 min | Background job processor (media downloads, etc.) |
| `instagram-refresh-token` | `supabase/functions/instagram-refresh-token/index.ts` | Daily | Refresh tokens expiring within 14 days |

### 2.4 Shared Modules

| File | Purpose |
|------|---------|
| `supabase/functions/_shared/instagram-token-refresh.ts` | Token refresh utilities |
| `supabase/functions/_shared/encryption.ts` | AES-256-GCM for tokens |
| `supabase/functions/_shared/hmac.ts` | OAuth state signing |

---

## PART 3: Database Schema

### 3.1 Tables

| Table | Purpose |
|-------|---------|
| `instagram_integrations` | OAuth connections per user (tokens encrypted) |
| `instagram_conversations` | DM threads with participants |
| `instagram_messages` | Individual messages |
| `instagram_scheduled_messages` | Future scheduled messages |
| `instagram_message_templates` | Reusable message templates |
| `instagram_template_categories` | Custom prospect categories |
| `instagram_job_queue` | Background job queue |
| `instagram_usage_tracking` | Monthly usage metrics |

### 3.2 Key Enums

- `instagram_connection_status`: connected, disconnected, expired, error
- `instagram_message_type`: text, media, story_reply, story_mention
- `instagram_message_status`: pending, sent, delivered, read, failed
- `message_direction`: inbound, outbound
- `scheduled_message_status`: pending, sent, cancelled, failed, expired

### 3.3 Migrations (18 total)

```
20260103_004_instagram_enums.sql
20260103_005_instagram_integrations.sql
20260103_006_instagram_conversations_messages.sql
20260103_007_instagram_scheduled_templates.sql
20260103_008_instagram_lead_source.sql
20260103_009_instagram_billing_feature.sql
20260104_001_instagram_template_rpc.sql
20260104_002_instagram_scheduled_cron.sql
20260105_004_instagram_contact_info.sql
20260105_010_instagram_template_categories.sql
20260105_011_instagram_job_queue.sql
20260105_012_instagram_realtime.sql
20260106_001_instagram_storage_bucket.sql
20260106_002_instagram_process_jobs_cron.sql
20260106_003_fix_instagram_cron_auth.sql
20260106_007_instagram_replica_identity.sql
20260106_011_fix_instagram_access_function.sql
20260108_007_instagram_refresh_token_cron.sql
```

---

## PART 4: UI Components

### 4.1 Core Instagram Components

Located in: `src/features/messages/components/instagram/`

| Component | Purpose |
|-----------|---------|
| `InstagramTabContent.tsx` | Main tab with feature gate |
| `InstagramSidebar.tsx` | Conversations list with search/filters |
| `InstagramConversationView.tsx` | Full conversation with messages |
| `InstagramConversationItem.tsx` | Single conversation in list |
| `InstagramMessageBubble.tsx` | Individual message display |
| `InstagramMessageInput.tsx` | Message composer |
| `InstagramWindowIndicator.tsx` | 24-hour window status |
| `InstagramPriorityBadge.tsx` | Priority toggle |
| `InstagramContactInfoPanel.tsx` | Contact email/phone/notes |
| `CreateLeadFromIGDialog.tsx` | Convert conversation to lead |
| `InstagramScheduleDialog.tsx` | Schedule messages |
| `InstagramTemplateSelector.tsx` | Template dropdown |
| `InstagramTemplatesSettings.tsx` | Templates management |
| `InstagramConnectCard.tsx` | OAuth connection card |

---

## PART 5: Identified Issues

### Issue 1: Periodic Conversation Sync Failures

**Symptom:** After initial load, conversations periodically fail to load/sync.

**Relevant Code Paths:**

1. **Initial Load Flow:**
   - `InstagramSidebar.tsx` → `useSyncInstagramConversations()` on mount
   - Calls `instagramService.syncConversations()`
   - Invokes edge function `instagram-get-conversations`

2. **Realtime Subscriptions:**
   - `useInstagramConversationsRealtime()` in `useInstagramRealtime.ts`
   - Subscribes to `postgres_changes` on `instagram_conversations` table

3. **Edge Function:** `instagram-get-conversations/index.ts`
   - 25-second timeout
   - Token refresh on error code 190
   - Rate limit handling (codes 4, 17, 32, 613)

**Potential Investigation Areas:**
- Token expiry during session (check `token_expires_at`)
- Rate limiting (200 calls/user/hour)
- Realtime subscription disconnects
- Network timeouts on Meta API calls
- CRON job interference with manual sync

### Issue 2: Missing Instagram Username Field in Lead Creation

**Current State:** `CreateLeadFromIGDialog.tsx` captures:
- firstName, lastName (parsed from display name)
- email, phone
- city, state
- availability, insuranceExperience
- whyInterested

**Missing:** Instagram username (`participant_username`) is available in conversation data but NOT stored on the lead record.

**Database Context:**
- `instagram_conversations.participant_username` stores the @handle
- `recruiting_leads` table does NOT have an `instagram_username` column
- When lead is created via `createLeadFromConversation()`, the `recruiting_lead_id` is stored on the conversation, but username is not copied to lead

**Recommended Fix:**
1. Add `instagram_username` column to `recruiting_leads` table
2. Modify `CreateLeadFromIGDialog.tsx` to pass username
3. Update `InstagramConversationRepository.createLeadFromConversation()` to store username

---

## PART 6: Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        UI COMPONENTS                            │
│  InstagramTabContent → InstagramSidebar → ConversationView      │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                    TANSTACK QUERY HOOKS                         │
│  useInstagramIntegration.ts  │  useInstagramRealtime.ts         │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                    SERVICE LAYER                                │
│              instagramService.ts (Facade)                       │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                  REPOSITORY LAYER                               │
│  Integration │ Conversation │ Message │ Template │ Scheduled    │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                SUPABASE DATABASE                                │
│  instagram_integrations │ instagram_conversations │ ...         │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                 EDGE FUNCTIONS                                  │
│  instagram-get-conversations │ instagram-send-message │ ...     │
└─────────────────────────┬───────────────────────────────────────┘
                          │
┌─────────────────────────▼───────────────────────────────────────┐
│                META GRAPH API                                   │
│          https://graph.instagram.com/v21.0                      │
└─────────────────────────────────────────────────────────────────┘
```

---

## PART 7: Key Technical Details

### 7.1 24-Hour Messaging Window
Instagram enforces a 24-hour window after user sends inbound message:
- Tracked in `can_reply_until` on conversations
- Updated on every inbound message
- Scheduled messages must be within window
- Window expiry handled by `instagram-process-scheduled` CRON

### 7.2 Token Management
- Long-lived tokens (~60 days)
- Refresh at day 53 (14 days before expiry)
- Daily CRON for proactive refresh
- Inline refresh on API errors (code 190)

### 7.3 Rate Limiting
- Instagram: 200 calls/user/hour
- Tracked in `api_calls_this_hour`
- Handles codes 4, 17, 32, 613

### 7.4 Job Queue
- Background processing for slow operations
- Atomic job claiming with row locking
- Exponential backoff retry
- 7-day cleanup

---

## PART 8: Key Code Snippets

### 8.1 Sync Conversations Hook (useSyncInstagramConversations)

**File:** `src/hooks/instagram/useInstagramIntegration.ts:289-324`

```typescript
export function useSyncInstagramConversations() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      integrationId,
      limit,
      cursor,
    }: {
      integrationId: string;
      limit?: number;
      cursor?: string;
    }): Promise<{
      conversations: InstagramConversation[];
      hasMore: boolean;
      nextCursor?: string;
      syncedCount: number;
    }> => {
      return instagramService.syncConversations(integrationId, {
        limit,
        cursor,
      });
    },
    onSuccess: (data, variables) => {
      // Update the conversations in cache
      queryClient.setQueryData(
        instagramKeys.conversations(variables.integrationId),
        data.conversations,
      );
      // Also invalidate to ensure any filtered queries are refreshed
      queryClient.invalidateQueries({
        queryKey: instagramKeys.conversations(variables.integrationId),
      });
    },
  });
}
```

### 8.2 Realtime Conversations Subscription

**File:** `src/hooks/instagram/useInstagramRealtime.ts:105-173`

```typescript
export function useInstagramConversationsRealtime(
  integrationId: string | null,
) {
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!integrationId) return;

    const channel = supabase
      .channel(`instagram-conversations:${integrationId}`)
      .on<InstagramConversationRow>(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "instagram_conversations",
          filter: `integration_id=eq.${integrationId}`,
        },
        (payload: ConversationPayload) => {
          if (payload.eventType !== "INSERT" || !payload.new) return;
          queryClient.invalidateQueries({
            queryKey: instagramKeys.conversations(integrationId),
          });
        },
      )
      .on<InstagramConversationRow>(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "instagram_conversations",
          filter: `integration_id=eq.${integrationId}`,
        },
        (payload: ConversationPayload) => {
          if (payload.eventType !== "UPDATE" || !payload.new) return;
          const updatedConversation = payload.new as InstagramConversationRow;
          // Update conversation in cache
          queryClient.setQueryData<InstagramConversationRow[]>(
            instagramKeys.conversations(integrationId),
            (oldConversations) => {
              if (!oldConversations) return oldConversations;
              return oldConversations.map((c) =>
                c.id === updatedConversation.id ? updatedConversation : c,
              );
            },
          );
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [integrationId, queryClient]);
}
```

### 8.3 Edge Function Error Handling (instagram-get-conversations)

**File:** `supabase/functions/instagram-get-conversations/index.ts:254-385`

```typescript
if (apiData.error) {
  // Handle token expiration - only mark expired for code 190 (Invalid Access Token)
  // Do NOT mark expired for rate limits (codes 4, 17, 32, 613) or server errors (1, 2)
  const isTokenInvalid = apiData.error.code === 190;
  const isRateLimit = [4, 17, 32, 613].includes(apiData.error.code);
  const isServerError = [1, 2].includes(apiData.error.code);

  if (isTokenInvalid) {
    // Check if token was recently expired - worth attempting refresh
    if (isTokenRecentlyExpired(integration.token_expires_at)) {
      const refreshResult = await attemptTokenRefresh(
        integration.access_token_encrypted,
      );
      if (refreshResult.success && refreshResult.newToken) {
        // Update the token in the database
        const updated = await updateIntegrationToken(...);
        if (updated) {
          // Tell client to retry - token was refreshed
          return new Response(JSON.stringify({
            ok: false,
            error: "Token was refreshed. Please retry your request.",
            code: "TOKEN_REFRESHED",
            retry: true,
          }), { status: 409 });
        }
      }
    }
    // Token refresh failed - mark as expired
    await markIntegrationExpired(supabase, integrationId, apiData.error.message);
    return new Response(JSON.stringify({
      ok: false,
      error: "Instagram token expired. Please reconnect.",
      code: "TOKEN_EXPIRED",
    }), { status: 401 });
  }

  if (isRateLimit) {
    return new Response(JSON.stringify({
      ok: false,
      error: "Rate limited by Instagram. Please try again later.",
      code: "RATE_LIMITED",
      retryAfter: 60,
    }), { status: 429 });
  }

  if (isServerError) {
    return new Response(JSON.stringify({
      ok: false,
      error: "Instagram is temporarily unavailable. Please try again.",
      code: "SERVER_ERROR",
    }), { status: 503 });
  }
}
```

### 8.4 Create Lead From Instagram Repository Method

**File:** `src/services/instagram/repositories/InstagramConversationRepository.ts:168-222`

```typescript
async createLeadFromConversation(
  conversationId: string,
  userId: string,
  leadData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    city?: string;
    state?: string;
    availability?: string;
    insuranceExperience?: string;
    whyInterested?: string;
  },
): Promise<string> {
  // Verify ownership first
  const conversation = await this.verifyOwnership(conversationId, userId);
  if (!conversation) {
    throw new Error("Conversation not found or you do not have permission");
  }

  // Call RPC to create lead
  const { data, error } = await this.client.rpc(
    "create_lead_from_instagram",
    {
      p_conversation_id: conversationId,
      p_first_name: leadData.firstName,
      p_last_name: leadData.lastName,
      p_email: leadData.email,
      p_phone: leadData.phone,
      p_city: leadData.city || "",
      p_state: leadData.state || "",
      p_availability: leadData.availability || "exploring",
      p_insurance_experience: leadData.insuranceExperience || "none",
      p_why_interested: leadData.whyInterested || "Contacted via Instagram DM",
    },
  );

  if (error) throw this.handleError(error, "createLeadFromConversation");
  return data;
}
```

### 8.5 Create Lead Dialog (UI Form Fields)

**File:** `src/features/messages/components/instagram/CreateLeadFromIGDialog.tsx:38-52`

```typescript
interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  city: string;
  state: string;
  availability: "full_time" | "part_time" | "exploring";
  insuranceExperience: "none" | "less_than_1_year" | "1_to_3_years" | "3_plus_years";
  whyInterested: string;
}

// NOTE: No instagramUsername field in the form - it's handled automatically by RPC
```

### 8.6 RPC Function - create_lead_from_instagram (SQL)

**File:** `supabase/migrations/20260103_008_instagram_lead_source.sql:63-154`

```sql
CREATE OR REPLACE FUNCTION create_lead_from_instagram(...)
RETURNS UUID
AS $$
DECLARE
  v_conversation instagram_conversations%ROWTYPE;
BEGIN
  -- Get conversation
  SELECT * INTO v_conversation FROM instagram_conversations WHERE id = p_conversation_id;

  -- Create the lead (instagram_username IS auto-populated from conversation!)
  INSERT INTO recruiting_leads (
    recruiter_id, imo_id, first_name, last_name, email, phone,
    city, state, availability, insurance_experience, why_interested,
    status, lead_source, instagram_conversation_id,
    instagram_username,  -- <-- THIS IS POPULATED AUTOMATICALLY
    utm_source, submitted_at
  ) VALUES (
    v_integration.user_id, v_integration.imo_id, p_first_name, p_last_name,
    p_email, p_phone, COALESCE(p_city, ''), COALESCE(p_state, ''),
    p_availability, p_insurance_experience, p_why_interested,
    'pending', 'instagram_dm', p_conversation_id,
    v_conversation.participant_username,  -- <-- PULLED FROM CONVERSATION
    'instagram', now()
  )
  RETURNING id INTO v_lead_id;

  -- Link the conversation back to the lead
  UPDATE instagram_conversations SET recruiting_lead_id = v_lead_id WHERE id = p_conversation_id;

  RETURN v_lead_id;
END;
$$ LANGUAGE plpgsql;
```

---

## PART 9: Clarification on Issue #2

**FINDING:** The `instagram_username` column **already exists** in the `recruiting_leads` table and the RPC function **already populates it** from `v_conversation.participant_username`.

**Database Evidence:**
- Migration `20260103_008_instagram_lead_source.sql:26-29` adds `instagram_username TEXT` column
- RPC function `create_lead_from_instagram` populates it at line 141

**Possible Confusion:**
1. The UI form (`CreateLeadFromIGDialog.tsx`) doesn't show the field because it's auto-populated
2. The leads list/view might not display the `instagram_username` column
3. There may be a bug where the conversation's `participant_username` is NULL

**Next Steps for Verification:**
- Check if leads created from IG have `instagram_username` populated in DB
- Check if leads list UI displays the `instagram_username` column
- Verify conversations have `participant_username` populated

---

## Summary

This document provides a complete inventory of the Instagram integration for senior engineer review.

**Issue #1 (Sync Failures):** Multiple investigation areas documented with code paths.

**Issue #2 (IG Username):** Already implemented at database level. Need to verify:
1. Is it being populated correctly?
2. Is it visible in the leads UI?

**Issue #3 (NEW - RLS Bug):** Users can see other agents' leads in their leads page.

---

## PART 10: Issue #3 - Leads RLS Bug Analysis

### Root Cause

The `leadsService.getMyLeads()` method at `src/services/leads/leadsService.ts:241-315` does NOT filter by `recruiter_id`. It relies entirely on RLS policies:

```typescript
async getMyLeads(filters?: LeadsFilters, ...) {
  let query = supabase
    .from("recruiting_leads")
    .select("*", { count: "exact" });
  // NO recruiter_id filter!
  ...
}
```

The RLS policy "Staff can view IMO leads" (line 129-145) allows anyone with `trainer`, `contracting_manager`, `imo_owner`, or `admin` roles to see **ALL leads in the entire IMO**:

```sql
CREATE POLICY "Staff can view IMO leads"
  ON recruiting_leads
  FOR SELECT
  TO authenticated
  USING (
    imo_id = get_my_imo_id() AND
    EXISTS (
      SELECT 1 FROM user_profiles
      WHERE id = auth.uid()
      AND (
        'trainer' = ANY(roles) OR
        'contracting_manager' = ANY(roles) OR
        'imo_owner' = ANY(roles) OR
        'admin' = ANY(roles)
      )
    )
  );
```

### Impact

Any user with a staff role sees ALL leads from ALL recruiters in their IMO, not just their own.

### Recommended Fix

**Option A (Frontend - Quick Fix):**
Add explicit `recruiter_id` filter in `getMyLeads()`:

```typescript
async getMyLeads(filters?: LeadsFilters, ...) {
  const { data: { user } } = await supabase.auth.getUser();
  let query = supabase
    .from("recruiting_leads")
    .select("*", { count: "exact" })
    .eq("recruiter_id", user?.id); // <-- ADD THIS
  ...
}
```

**Option B (Backend - More Robust):**
Create separate "view my leads" vs "view all IMO leads" functionality, or modify RLS policies.

### Files to Modify

1. `src/services/leads/leadsService.ts` - Add `recruiter_id` filter
2. Optionally: `supabase/migrations/` - New migration to tighten RLS if needed

---

## PART 11: Summary of All Issues

| # | Issue | Status | Fix Location |
|---|-------|--------|--------------|
| 1 | Instagram sync failures | Investigation needed | Edge functions + realtime hooks |
| 2 | IG username not visible in leads UI | Display issue | Leads list/detail UI components |
| 3 | Users see other agents' leads | **SECURITY BUG** | `leadsService.ts:247` |
